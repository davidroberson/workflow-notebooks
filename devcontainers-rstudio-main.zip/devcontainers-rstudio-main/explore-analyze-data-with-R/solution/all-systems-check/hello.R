# Function that returns an awesome message
say_hello <- function(name) {
  message(paste0("Hello, ", name, ":) In this module, we learn how to Explore
  and Analyze Data with R."))
}

say_hello("remote world")